import os
import re
import random 
import subprocess
data_source="class_wzk"#input("describe the test data:")
xianshi=1#input("dou you want to see the line of asm code?(y/n):")=="y"
#data_source=""
case=input("Your test files num >1?(y/n):")=="y"
xlinx="D:\\Xilinx\\14.7\\ISE_DS\\ISE" 
#case=
#xlinx=input("your xilinx src is:")
if(case):
    file_src=input("input asm test files folder src:(must like this D:\\P5\\test\\)")
    #file_src=""
    file_list=os.listdir(file_src)

    #k=1
    # for name in file_list:
    #     namek="testpoint"+str(k)+".asm"
    #     try:
    #         os.rename(file_src+name,file_src+namek)
    #     except:
    #         pass
    #     k=k+1
    # file_num=k-1
    file_num=len(file_list)
    print(file_num)
    error_list=[]
    wrong_cnt=0
    path=os.path.dirname(os.path.realpath(__file__))
    os.chdir(path)  
    info_name="test_info_"+data_source+".txt"
    f=open(info_name,"w")
    for j in range(1,file_num+1):  
        path=os.path.dirname(os.path.realpath(__file__))
        os.chdir(path)  
        asmfilename=file_src+file_list[j-1]
        time="2000us"
        filelist=os.walk(path) 
        os.environ['XILINX']=xlinx
        with open("mips.prj","w") as prj:
            for folder in filelist:
                for file in folder[2]:
                    if(len(file.split("."))>1 and file.split(".")[1]=="v"):
                        prj.write("verilog work \""+folder[0]+"\\"+file+"\"\n")
        with open("mips.tcl","w") as tcl:
            tcl.write("run "+time+";\nexit;\n")
        os.system("java -jar Mars.jar db a nc mc CompactDataAtZero dump .text HexText code.txt 1000000 "+asmfilename)
        os.system("java -jar Mars.jar db a nc mc CompactDataAtZero dump 0x00004180-0x00005180 HexText code_handler.txt "+asmfilename)
        os.system("java -jar Mars.jar  db nc mc CompactDataAtZero dump .text HexText code.txt >ans.txt 1000000 "+asmfilename)
        os.system(xlinx+"\\bin\\nt64\\fuse "+"--nodebug  --prj mips.prj -o mips.exe mips_tb >log.txt")
        os.system("mips.exe -nolog -tclbatch mips.tcl >my.txt")

        process=0
        with open("my.txt","r") as my:
            lines=my.readlines()
            if(len(lines)==0):
                print("fail to simulate")
                os._exit(1)
            if(lines[0][0]=='I'):
                process=1
        my.close()
        n=0
        while(1):
            if "@" in lines[n]:
                break
            else: 
                n=n+1
        if(process):
            with open("my.txt","w") as my:
                my.writelines(lines[n:])
        i=0
        biao=0
        with open("my.txt","r") as my:
            with open("ans.txt","r") as ans:
                while(1):
                    i+=1
                    l1=my.readline()
                    if(l1!="" and l1!=None):
                        l1="@"+l1.strip().split("@")[-1]
                    l2=ans.readline().strip()
                    if((l1== "" or l1==None)and(l2=="" or l2==None)):
                        break
                    elif l1!=l2 and not "$ 0"in l2 and not "$ 0" in  l1:
                        biao=1
                        error_list.append(asmfilename)
                        try:
                            code_line=int(l1[6:9],16)/4+1
                        except:
                            code_line=0
                            xianshi=0
                        #pattern = re.compile(r"@[0-9a-z]{8}:\s[*][0-9]{8}\s<=\s[0-9]{8}")
                        # print(l1)
                        # print(l2)
                        # if(l1[:12]==l2[:12] and l1[17:20]==l2[17:20] and l1[24:31]==l2[24:31]):
                        #     biao=0
                        #     error_list.pop()
                        #     continue
                        # try:
                        #     s1=pattern.match(l1).group()
                        #     s2=pattern.match(l2).group()
                        #     print(s1)
                        #     print(s2)
                        #     if(s1[:12]==s2[:12] and s1[17:20]==s2[17:20] and s1[24:31]==s2[24:31]):
                        #         print("success")
                        #         biao=0
                        # except:
                        #     pass
                        # if(biao==0):
                        #     continue
                        if(xianshi==1):
                            if l2=="" or l2 == None:  
                                print("Wrong answer occur in line %d of your ans and in line %d of test code: "%(i,code_line)+"we got "+l1+" when we expected Nothing")
                                f.write("wrong answer on point %d\nWrong answer occur in line %d of your ans: "%(j,i)+"we got "+l1+" when we expected Nothing\n")
                            else:
                                print("Wrong answer occur in line %d of your ans and in line %d of test code: "%(i,code_line)+"we got "+l1+" when we expected "+l2)
                                f.write("wrong answer on point %d\nWrong answer occur in line %d of your ans: "%(j,i)+"we got "+l1+" when we expected "+l2+"\n")
                        else:
                            if l2=="" or l2 == None:  
                                print("Wrong answer occur in line %d of your ans: "%(i)+"we got "+l1+" when we expected Nothing")
                                f.write("wrong answer on point %d\nWrong answer occur in line %d of your ans: "%(j,i)+"we got "+l1+" when we expected Nothing\n")
                            else:
                                print("Wrong answer occur in line %d of your ans: "%(i)+"we got "+l1+" when we expected "+l2)
                                f.write("wrong answer on point %d\nWrong answer occur in line %d of your ans: "%(j,i)+"we got "+l1+" when we expected "+l2+"\n")
                        break
                        
                if biao==0:
                    print("Accepted on the point %d"%j)
                    f.write("Accepted on the point %d\n"%j)
                else:
                    print("Wrong on the point %d"%j)
                    wrong_cnt=wrong_cnt+1
        my.close()
        ans.close()
    if(error_list):
        print("------------------------------------\nYou have %d wrong answer\n test data description:%s\nthey are:"%(wrong_cnt,data_source))
        f.write("------------------------------------\nYou have %d wrong answer\n test data description:%s\nthey are:\n"%(wrong_cnt,data_source))
        for x in error_list:
            print(x)
            f.write(x+"\n")
    else:
        print("------------------------------------\ncongratulations!You accepted %d point\ntest data description:%s"%(file_num,data_source))
        f.write("------------------------------------\ncongratulations!You accepted %d point\ntest data description:%s\n"%(file_num,data_source))
    f.close()
    os._exit(1)
else:
    file_name="E:\computer\\verilog_ISE\CO\p7_test1\\testpoint4.asm"#input("input asm test file name(can have src):")
    path=os.path.dirname(os.path.realpath(__file__))
    os.chdir(path)  
    asmfilename=file_name
    time="2000us"
    filelist=os.walk(path) 
    os.environ['XILINX']=xlinx
    with open("mips.prj","w") as prj:
        for folder in filelist:
            for file in folder[2]:
                if(len(file.split("."))>1 and file.split(".")[1]=="v"):
                    prj.write("verilog work \""+folder[0]+"\\"+file+"\"\n")
    with open("mips.tcl","w") as tcl:
        tcl.write("run "+time+";\nexit;\n")
    os.system("java -jar Mars.jar db a nc mc CompactDataAtZero dump .text HexText code.txt 100000 "+asmfilename)
    os.system("java -jar Mars.jar db a nc mc CompactDataAtZero dump 0x00004180-0x00005180 HexText code_handler.txt "+asmfilename)
    os.system("java -jar Mars.jar  db nc mc CompactDataAtZero dump .text HexText code.txt >ans.txt 100000 "+asmfilename)
    os.system(xlinx+"\\bin\\nt64\\fuse "+"--nodebug  --prj mips.prj -o mips.exe mips_tb >log.txt")
    os.system("mips.exe -nolog -tclbatch mips.tcl >my.txt")

    process=0
    with open("my.txt","r") as my:
        lines=my.readlines()
        if(len(lines)==0):
            print("fail to simulate")
            os._exit(1)
        if(lines[0][0]=='I'):
            process=1
    my.close()
    n=0
    while(1):
            if "@" in lines[n]:
                break
            else: 
                n=n+1
    if(process):
        with open("my.txt","w") as my:
            my.writelines(lines[n:])
    i=0
    biao=0
    wrong_cnt=0
    with open("my.txt","r") as my:
        with open("ans.txt","r") as ans:
            while(1):
                i+=1
                l1=my.readline()
                if(l1!="" and l1!=None):
                    l1="@"+l1.strip().split("@")[-1]
                l2=ans.readline().strip()
                if((l1== "" or l1==None)and(l2=="" or l2==None)):
                    break
                elif l1!=l2 and not "$ 0"in l2 and not "$ 0" in  l1:
                    biao=1
                    if(l1[:12]==l2[:12] and l1[17:20]==l2[17:20] and l1[24:31]==l2[24:31]):
                        biao=0
                        continue
                    try:
                        code_line=int("0x"+l1[6:9],16)/4+1
                    except:
                        xianshi=0
                    if(xianshi==1):
                        if l2=="" or l2 == None:  
                            print("Wrong answer occur in line %d of your ans and in line %d of test code: "%(i,code_line)+"we got "+l1+" when we expected Nothing")
                        else:
                            print("Wrong answer occur in line %d of your ans and in line %d of test code: "%(i,code_line)+"we got "+l1+" when we expected "+l2)
                    else:
                        if l2=="" or l2 == None:  
                            print("Wrong answer occur in line %d of your ans: "%(i)+"we got "+l1+" when we expected Nothing")
                        else:
                            print("Wrong answer occur in line %d of your ans: "%(i)+"we got "+l1+" when we expected "+l2)
                        
                    break
                    
            if biao==0:
                print("Accepted on this point")
            else:
                print("Wrong on the point")
                wrong_cnt=wrong_cnt+1
    my.close()
    ans.close()
    os._exit(1)

#E:\computer\verilog_ISE\CO\p6\test\ch\testpoint2.asm