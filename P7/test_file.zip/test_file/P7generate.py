import random
import os
testnum=3
mipsDict={}
mipsDict['nop']=['nop']
mipsDict['cal_r']=['add', 'addu', 'sub', 'subu', 'and', 'or', 'nor', 'xor',  'sllv', 'slt', 'sltu',  'srav',  'srlv']
mipsDict['cal_i']=['ori', 'addi', 'addiu', 'andi', 'xori']
mipsDict['lui']=["lui"]
mipsDict['jump']=["j","jal"]
mipsDict['jr']=["jr"]
mipsDict['jalr']=["jalr"]
mipsDict['b']=['beq', 'bne']
mipsDict['b1']=['bgtz', 'blez', 'bgez', 'bltz']
mipsDict['load']=['lw', 'lb', 'lbu', 'lh', 'lhu']
mipsDict['store']=["sw","sb","sh"]
mipsDict['cal_md']=['mult', 'multu', 'div', 'divu']
mipsDict['r_md']=['mfhi', 'mflo']
mipsDict['w_md']=['mthi','mtlo']
mipsDict['eret']=['eret']
mipsDict['cp0']=['mfc0','mtc0']
mipsDict['s']=['sll','sra','srl']
mipsDict['s1']=['slti', 'sltiu']
n2lei=['nop','cal_i','cal_r','load','store','lui','jr','jalr','jump','cal_md','w_md','r_md','b1','cp0','b','s','s1','eret']
lei2n={ "nop":0, "cal_i":1, "cal_r":2, "load":3, "store":4, "lui":5, "jr":6, "jalr":7, "jump":8, 
        "cal_md":9, "w_md":10, "r_md":11, "b1":12, "cp0":13, "b":14, "s":15, "s1":16, "eret":17}
class mipscode:
    instr=None
    rs=1
    rt=1
    rd=1
    lei=0
    imm16=0
    cp0=0
    label=""

    mipsDict={}
    mipsDict['nop']=['nop']
    mipsDict['cal_r']=['add', 'addu', 'sub', 'subu', 'and', 'or', 'nor', 'xor',  'sllv', 'slt', 'sltu',  'srav',  'srlv']
    mipsDict['cal_i']=['ori', 'addi', 'addiu', 'andi', 'xori']
    mipsDict['lui']=["lui"]
    mipsDict['jump']=["j","jal"]
    mipsDict['jr']=["jr"]
    mipsDict['jalr']=["jalr"]
    mipsDict['b']=['beq', 'bne']
    mipsDict['b1']=['bgtz', 'blez', 'bgez', 'bltz']
    mipsDict['load']=['lw', 'lb', 'lbu', 'lh', 'lhu']
    mipsDict['store']=["sw","sb","sh"]
    mipsDict['cal_md']=['mult', 'multu', 'div', 'divu']
    mipsDict['r_md']=['mfhi', 'mflo']
    mipsDict['w_md']=['mthi','mtlo']
    mipsDict['eret']=['eret']
    mipsDict['cp0']=['mfc0','mtc0']
    mipsDict['s']=['sll','sra','srl']
    mipsDict['s1']=['slti', 'sltiu']
    n2lei=['nop','cal_i','cal_r','load','store','lui','jr','jalr','jump','cal_md','w_md','r_md','b1','cp0','b','s','s1','eret']
    lei2n={ "nop":0, "cal_i":1, "cal_r":2, "load":3, "store":4, "lui":5, "jr":6, "jalr":7, "jump":8, 
            "cal_md":9, "w_md":10, "r_md":11, "b1":12, "cp0":13, "b":14, "s":15, "s1":16, "eret":17}
    def __init__(self,lei,rs=1,rt=1,rd=1,imm16=0,instr=None,cp0=0,label=None):
        self.lei=lei
        self.rs=rs
        self.rt=rt
        self.rd=rd
        self.imm16=imm16
        self.instr=instr
        self.cp0=cp0
        self.label=label
    def getMipsCode(self):
        if self.lei==0: #nop
            return "nop"
        elif(self.lei==1): #cal_i
            return "%s $%d $%d %d" % (self.instr,self.rt,self.rs,self.imm16)
        elif self.lei==2: #cal_r
            return "%s $%d $%d $%d" % (self.instr,self.rd,self.rt,self.rs)
        elif self.lei==3: #load
            return "%s $%d %d($%d)"%(self.instr,self.rt,self.imm16,self.rs)
        elif self.lei==4: #store
            return "%s $%d %d($%d)"%(self.instr,self.rt,self.imm16,self.rs)
        elif self.lei==5: #lui
            return "lui $%d %d"%(self.rt,self.imm16)
        elif self.lei==6: #jr
            return "%s $%d"%("jr",self.rs)
        elif self.lei==7: #jalr
            return "%s $%d $%d"%("jalr",self.rd,self.rs)
        elif self.lei==8: #jump
            return "%s %s" % (self.instr,self.label)
        elif self.lei==9: #cal_md
            return "%s $%d $%d"%(self.instr,self.rs,self.rt)
        elif self.lei==10: #w_md
            return "%s $%d"%(self.instr,self.rd)
        elif self.lei==11: #r_md
            return "%s $%d"%(self.instr,self.rs)
        elif self.lei==12: #b1
            return "%s $%d %s"%(self.instr,self.rs,self.label)
        elif self.lei==13: #mf/mt c0
            return "%s $%d $%d"%(self.instr,self.rt,self.cp0)
        elif self.lei==14: #b
            return "%s $%d $%d %s"%(self.instr,self.rs,self.rt,self.label)
        elif self.lei==15: #s
            return "%s $%d $%d %d" % (self.instr,self.rt,self.rs,self.imm16/(2**11))
        elif self.lei==16: #s1
            return "%s $%d $%d %d" % (self.instr,self.rt,self.rs,self.imm16/4)
        elif self.lei==17: #eret
            return "%s"%("eret")
        else:
            return  "nop"
    def getInstr(self):
        dict1=self.mipsDict
        if(self.instr):
            for x in dict1:
                if(self.instr in dict1[x]):
                    self.lei=self.n2lei.index(self.instr)
                    break
                else:
                    self.lei=0
        else:
            name=self.n2lei[self.lei]
            self.instr=dict1[name][random.randint(0,len(dict1[name])-1)]
    def getMipsStr(self):
        self.getInstr()
        return self.getMipsCode()
def exhand():
    return '''
.ktext 0x4180
mfc0 $28 $14
ori $29 $0 0x4ffc
bgt $28 $29 next
ori $29 $0 0x3000
blt $28 $29 next
normal:nop
eret
nop
next:
la $29 label1
mtc0 $29 $14
eret
'''  
def hazardTestMake(leil,src):
    l=[random.randint(0,31) for i in range(3)]
    for i in l:
        if(l==28):
            l=27
        elif l==29:
            l=30
    m=len(leil)
    s=""
    for x in leil:
        s=s+"+"+x
    #print(s)
    fname=src+"\\Test"+s+".asm"
    leil=[lei2n[leil[i]] if isinstance(leil[i],str) else leil[i] for i in range(m)]
    n=20
    path=os.path.dirname(os.path.realpath(__file__))
    os.chdir(path)  
    with open(fname,"w") as f:
        for j in range(m):
            f.write("label%d:nop\n"%j)
            for i in range(n):
                a=random.randint(0,m-1)
                num=[random.randint(0,2) for i in range(3)]
                imm16=random.randint(0,0xfff)
                f.write(mipscode(leil[a],l[num[0]],l[num[1]],l[num[2]],imm16,cp0=random.randint(12,15),label="label"+str(random.randint(0,m-1))).getMipsStr()+"\n")
        f.write(exhand())
  

def get_one_testpoint(file_name):
    path=os.path.dirname(os.path.realpath(__file__))
    os.chdir(path)  
    with open(file_name,"w") as f:
        f.write("ori $gp $0 0"+"\n")
        f.write("ori $sp $0 0"+"\n")
        f.write("mtc0 $0 $15\n")
        n=10
        for i in range(0,n):
            f.write("label%d:nop\n"%(i))
            l=[]
            for i in range(5):
                l.append(random.randint(0,31))
            for i in l:
                if(i==28):
                    i=27
                elif i==29:
                    i=30
            imm16=random.randint(0,0xffff)
            lei1=0
            for i in range(50):
                lei=random.randint(1,16)
                if((lei1==6 or lei1==7 or lei1==8 or lei1==12 or lei1==14) and (lei==6 or lei==7 or lei==8 or lei==12 or lei==14)):
                    lei=1  
                a=mipscode(lei,l[random.randint(0,4)],l[random.randint(0,4)],l[random.randint(0,4)],imm16,cp0=random.randint(12,15),label="label"+str(random.randint(0,n-1)))
                f.write(a.getMipsStr()+"\n")
                lei1=lei
        f.write(exhand())
def getrandompoint(num,src):
    for i in range(num):
        pointname="%s//testpoint%d.asm"%(src,i+1)   
        get_one_testpoint(pointname)     
#main()
def gethazardpoint(l,src):
    if(l==None):  
        for i in mipsDict:
            for j in mipsDict:
            # print(i,j)
                hazardTestMake([i,j],src)
    else:
        hazardTestMake(l,src)
getrandompoint(100,"test_fzc")
gethazardpoint(None,"test1")



        
